#include <stdio.h>
//result of multiplying numbers by 0

int main () {
    int x = 3, y = 4;
    int v = 0; 
    //int v = 42; //EQ MUTANT id scalar_value_mutator Replaces zeros with 42, and non-zeros with 0

    if (x != 0) {
     //  if (x == 0) {  //EQ MUTANT cxx_ne_to_eq Replaces != with ==

       v = x * 0;

    } else {
       v = 0;
    }

    printf("%d\n", v);

    return 0;

}