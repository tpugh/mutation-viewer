#include <stdio.h>
#include <stdlib.h>
//absolute result of subtracting 2 numbers 

int main () {
    int x = 7, y = 4;
    int v = 0; 
    //int v = 42; //EQ MUTANT id scalar_value_mutator Replaces zeros with 42, and non-zeros with 0

    if (x > 0 && y > 0 && x > y) {
    // if (x >= 0 && y > 0 && x > y) {  //EQ MUTANT id cxx_gt_to_ge  Replaces > with >=
    // if (x > 0 && y >= 0 && x > y) {   //EQ MUTANT id cxx_gt_to_ge  Replaces > with >=
    // if (x > 0 && y > 0 && x >= y) {   //EQ MUTANT id cxx_gt_to_ge  Replaces > with >=
       v = x - y;

    } else {
       v = abs(x - y);
    }

    printf("%d\n", v);

    return 0;

}