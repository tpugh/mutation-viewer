#include <stdio.h>

int main () {
    int x = 3, y = 4;
    int v = 0; 
    //int v = 42; //EQ MUTANT id scalar_value_mutator Replaces zeros with 42, and non-zeros with 0
    if (x > y) {
      // if (x >= y) { //EQ MUTANT id cxx_gt_to_ge  Replaces > with >=
        v = x;
    } else {
        v = y;
    }

    printf("%d\n", v);

    return 0;

}