#include <stdio.h>

int main() {

    int a = 3, b = 4;
    int temp = 0; 
   // int temp = 42; //EQ MUTANT id scalar_value_mutator Replaces zeros with 42, and non-zeros with 0

    if (a > b) {
       // if (a >= b) //EQ MUTANT id cxx_gt_to_ge Replaces > with >=
        temp = a;
        a = b;
        b = temp;
    }

    printf("%d\n%d\n", a, b);

}